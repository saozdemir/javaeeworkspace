package academy.learnprogramming.interfaces;

public interface Salute {
    String salute(String name);
}
