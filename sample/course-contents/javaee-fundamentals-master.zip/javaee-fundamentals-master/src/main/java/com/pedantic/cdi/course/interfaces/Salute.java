package com.pedantic.cdi.course.interfaces;

public interface Salute {
    String salute(String name);
}
