# javaee-desingpatters
Companion code to modern design patterns with Java EE 8 Course.

This code compiles against Java EE 8 API. You'd need the Glassfish 5 application server to run it. 
