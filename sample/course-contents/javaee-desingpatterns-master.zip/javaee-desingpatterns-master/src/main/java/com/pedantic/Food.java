package com.pedantic;

public interface Food {
    String prepare();
}
