# javaee-stripe
Companion code to Stripe integration with Java EE course.

This is a fully functional code that shows integration of Stripe Checkout with Java EE using CDI, EJB, and JSF. 

It's a Javav EE 8 app that requires a Glassfish 5 application server to run. 

You will also need to have your Stripe API keys to be able to run the sample.
