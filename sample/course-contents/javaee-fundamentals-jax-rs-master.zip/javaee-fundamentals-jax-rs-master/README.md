Companion code to Java EE Bootcamp Jax-RS Course on Udemy
This code is a details the JAX-RS API from Java EE spec. It is built with Maven and runs on any EE 7 certified application server. The jaxrs21 branch however requires Glassfish 5 to run because it is based on JAX-RS 2.1. Feel free to send pull requests especially on JAX-RS 2.1
