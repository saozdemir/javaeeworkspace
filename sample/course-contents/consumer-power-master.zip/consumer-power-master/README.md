# consumer-power
Companion app to the Harried Developer's Guide to Java EE course on Udemy
